# Alternative version

This is a version of the script in which you specify a list of classes of programs that you *do* want to swallow the terminal in a file called "swallow" and everything else isn't swallowed.
